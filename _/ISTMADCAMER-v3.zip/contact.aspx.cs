﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ISTMADCAMER
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void contactBtn_Click(object sender, EventArgs e)
        {
            // display the feedback panel
            feedbackPanel.Visible = true;

            // get the details
            string name = nameTB.Text;
            string email = emailTB.Text;
            string phoneNum = phoneNumTB.Text;
            string subjet = subjetTB.Text;
            string message = messageTB.Text;


            // validate inputs are not empty
            if (String.IsNullOrWhiteSpace(name)
                || String.IsNullOrWhiteSpace(email)
                || String.IsNullOrWhiteSpace(phoneNum)
                || String.IsNullOrWhiteSpace(subjet)
                || String.IsNullOrWhiteSpace(message))

            {
                // inputs cannot be empty
                feedbackPanel.CssClass = "alert alert-danger";
                feedbackMsgLbl.Text = "Please input all fields.";
                return;
            }

            // validate email
            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(email);
            if (!match.Success)
            {
                // email format not valid
                feedbackPanel.CssClass = "alert alert-danger";
                feedbackMsgLbl.Text = "Email format is not valid.";
                return;
            }

            MailMessage feedBack = new MailMessage();
            feedBack.To.Add("charlessolutionssarl@gmail.com");
            feedBack.From = new MailAddress("charlessolutionssarl@gmail.com");
            feedBack.Subject = ("New Message from website (FEFEO GROUP SARL)");
            feedBack.Body = "Sender Name: " + nameTB.Text + "<br><br>Sender Email: " + emailTB.Text + " <br><br>Mobile Number: " + phoneNumTB.Text + " <br><br>Subjet: " + subjetTB.Text + " <br><br>Message:<br><br>" + messageTB.Text;
            feedBack.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = ConfigurationManager.AppSettings["Host"];
            smtp.Port = int.Parse(ConfigurationManager.AppSettings["EmailPort"]);
            smtp.EnableSsl = true;
            NetworkCredential NetworkCred = new NetworkCredential(ConfigurationManager.AppSettings["SMTPuser"], ConfigurationManager.AppSettings["SMTPpassword"]);
            smtp.Credentials = NetworkCred;
            smtp.Send(feedBack);
            // display email sent successfully
            feedbackPanel.CssClass = "alert alert-success";
            feedbackMsgLbl.Text = "Thank you! We will get back to you shortly.";

            Response.AddHeader("Refresh", "8");
        }
    }
}