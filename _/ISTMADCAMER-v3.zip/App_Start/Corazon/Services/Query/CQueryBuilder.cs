﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CorazonHeart
{
    /// <summary>
    /// Provides functionalities to build SQL queries for different scenarios.
    /// </summary>
    public class CQueryBuilder
    {
        public void AddParameter(ref SqlCommand cmd, string parameterName, SqlDbType dbType, object value)
        {
            if (value == null)
            {
                cmd.Parameters.Add(parameterName, dbType).Value = DBNull.Value;
            }
            else
            {
                cmd.Parameters.Add(parameterName, dbType).Value = value;
            }
        }

        //public SqlCommand BuildInsertQuery(string tableName, List<string> columnName, List<object>)
        //{

        //}

        //public string BuildOptionalUpdateQuery(string tableName, List<string> columnName, List<object> columnValues)
        //{

        //}
    }
}