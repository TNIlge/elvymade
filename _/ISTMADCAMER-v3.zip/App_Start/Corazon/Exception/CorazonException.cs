﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Custom application exception.
/// </summary>
public class CorazonException
{
    /// <summary>
    /// Constructor - logic when exception is thrown will be processed here.
    /// </summary>
	public CorazonException(Exception ex)
	{
        // get the current URL
        string URL = HttpContext.Current.Request.RawUrl;

        // build the error page URL, passing the current URL for back functionality
        string errorPageURL = String.Format("~/error?goback={0}", URL);

        // redirect
        HttpContext.Current.Response.Redirect(errorPageURL);
	}
}