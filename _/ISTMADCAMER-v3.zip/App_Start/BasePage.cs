﻿using CorazonHeart;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;

public class BasePage : System.Web.UI.Page
{
    /// <summary>
    /// Initialize the culture of the page to the language preferred.
    /// </summary>
    protected override void InitializeCulture()
    {
        // get the app object
        Corazon app = Corazon.Current;

        // get the preferred language from browser's cookie
        CLanguage.Language preferredLanguage = app.Services.Language.PreferredLanguage;

        // based on the preferred language, set the language and culture to variables
        string lang = preferredLanguage.ToString();
        string culture = app.Services.Language.GetCulture(preferredLanguage);

        // set the current culture
        Thread.CurrentThread.CurrentCulture = CultureInfo.CreateSpecificCulture(culture);
        Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture);

        // call base class initialize culture
        base.InitializeCulture();
    }
}
