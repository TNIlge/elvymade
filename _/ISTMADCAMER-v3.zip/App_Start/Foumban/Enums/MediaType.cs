﻿/// <summary>
/// Enumerator for all the user types as stored in UserType table.
/// </summary>
public enum MediaType
{
    All = 0,
    Image = 1,
    Video = 2
}