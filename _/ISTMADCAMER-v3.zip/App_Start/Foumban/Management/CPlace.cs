﻿using CorazonHeart;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Provides interaction functionalities with Place table.
/// </summary>
public class CPlace
{
    #region CRUD
    /// <summary>
    /// Get all places.
    /// </summary
    /// <param name="sortColumnName">(Optional) The column name to sort.</param>
    /// <param name="sortOrder">(Optional) Sort order to retrieve the data.</param>
    /// <returns>Returns all matching room facilities if successful, null otherwise.</returns>
    public DataTable GetAll(string sortColumnName = "", SortOrder sortOrder = SortOrder.Unspecified)
    {
        // get the app object
        Fefeo app = Fefeo.Current;

        // init extended query and order query rule
        string extendedQuery = "", orderQueryRule = "";

        // if sort order is not unspecified, build the query for it
        if (sortOrder != SortOrder.Unspecified)
        {
            if (sortOrder == SortOrder.Ascending)
                orderQueryRule = String.Format(" ORDER BY {0}", sortColumnName);
            else
            {
                orderQueryRule = String.Format(" ORDER BY {0} DESC", sortColumnName);
            }
        }

        // init result
        DataTable result = new DataTable();

        try
        {
            // init con
            using (SqlConnection con = new SqlConnection(app.ConnectionString))
            {
                con.Open();

                // init query
                string query = "SELECT * FROM PlaceView"
                    + extendedQuery
                    + orderQueryRule;
                SqlCommand cmd = new SqlCommand(query, con);

                // execute the query and store the result in the DataTable
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(result);
            }
        }
        catch (Exception)
        {
            // error occured
            result = null;
        }

        return result;
    }

    /// <summary>
    /// Get a specified place.
    /// </summary>
    /// <param name="id">The ID of the place to get.</param>
    /// <returns>Returns the data of the place if exists, null/empty DataTable otherwise.</returns>
    public DataTable Get(int id)
    {
        // get the app object
        Fefeo app = Fefeo.Current;

        // init result
        DataTable result = new DataTable();

        try
        {
            // init con
            using (SqlConnection con = new SqlConnection(app.ConnectionString))
            {
                con.Open();

                // init query
                string query = "SELECT * FROM PlaceView WHERE ID=@ID";
                SqlCommand cmd = new SqlCommand(query, con);

                // parameters
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;

                // execute the query and store the result in the DataTable
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(result);
            }
        }
        catch (Exception)
        {
            // error occured
            result = null;
        }

        return result;
    }


    /// <summary>
    /// Get all places by keyword.
    /// </summary
    /// <param name="sortColumnName">The function will get all place names which match this keyword.</param>
    /// <param name="sortColumnName">(Optional) The column name to sort.</param>
    /// <param name="sortOrder">(Optional) Sort order to retrieve the data.</param>
    /// <returns>Returns all matching places if successful, null otherwise.</returns>
    public DataTable GetAllByKeyword(string keyword, string sortColumnName = "", SortOrder sortOrder = SortOrder.Unspecified)
    {
        // get the app object
        Fefeo app = Fefeo.Current;

        // init extended query and order query rule
        string extendedQuery = "", orderQueryRule = "";

        // if sort order is not unspecified, build the query for it
        if (sortOrder != SortOrder.Unspecified)
        {
            if (sortOrder == SortOrder.Ascending)
                orderQueryRule = String.Format(" ORDER BY {0}", sortColumnName);
            else
            {
                orderQueryRule = String.Format(" ORDER BY {0} DESC", sortColumnName);
            }
        }

        // init result
        DataTable result = new DataTable();

        try
        {
            // init con
            using (SqlConnection con = new SqlConnection(app.ConnectionString))
            {
                con.Open();

                // init query
                string query = "SELECT * FROM PlaceView WHERE Name LIKE @Name"
                    + extendedQuery
                    + orderQueryRule;
                SqlCommand cmd = new SqlCommand(query, con);

                // assign parameters
                cmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = string.Format("%{0}%", keyword);

                // execute the query and store the result in the DataTable
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(result);
            }
        }
        catch (Exception)
        {
            // error occured
            result = null;
        }

        return result;
    }

    /// <summary>
    /// Add a new place.
    /// </summary>
    /// <param name="name">The name of the place.</param>
    /// <param name="description">(Optional) The description of the place in English.</param>
    /// <param name="descriptionFr">(Optional) The description of the place in French.</param>
    /// <returns>Returns the ID of the place if successful, null otherwise.</returns>
    public int? Add(string name, string description = null, string descriptionFr = null)
    {
        // init return value
        int? id = null;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // execute insert query to db
            id = corazon.Services.Query.Execute(CQuery.QueryType.Insert,
                    "Place",
                    new List<string>() { "Name", "Description", "DescriptionFrench" },
                    new List<object>() { name, description, descriptionFr }
                    );
        }
        catch (Exception)
        {
            id = null;
        }

        return id;
    }

    /// <summary>
    /// Update place details.
    /// </summary>
    /// <param name="id">The ID of the place to update.</param>
    /// <param name="name">The name of the place.</param>
    /// <param name="description">(Optional) The description of the place in English.</param>
    /// <param name="descriptionFr">(Optional) The description of the place in French.</param>
    /// <returns>Returns true if successful, false otherwise.</returns>
    public bool Update(int id, string name, string description = null, string descripionFr = null)
    {
        // init return value
        bool isSuccess = false;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // execute insert query to db
            string condition = "ID=" + id;
            isSuccess = corazon.Services.Query.Execute(CQuery.QueryType.Update,
                    "Place",
                    new List<string>() { "Name", "Description", "DescriptionFrench" },
                    new List<object>() { name, description , descripionFr},
                    condition, true
                    ) != null;
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }

    /// <summary>
    /// Delete a place.
    /// </summary>
    /// <param name="id">The ID of the place to delete.</param>
    /// <returns>Returns true if successful, false otherwise.</returns>
    public bool Delete(int id)
    {
        // init return value
        bool isSuccess = false;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // execute insert query to db
            string condition = "ID=" + id;
            isSuccess = corazon.Services.Query.Execute(CQuery.QueryType.Delete,
                    "Place",
                    null,
                    null,
                    condition
                    ) != null;
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }
    #endregion
}