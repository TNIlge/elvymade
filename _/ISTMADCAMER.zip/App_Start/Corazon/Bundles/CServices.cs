﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CorazonHeart;

namespace CorazonHeart
{
    /// <summary>
    /// Provides external services.
    /// </summary>
    public class CServices
    {
        #region Data Members
        public CLanguage Language { get; set; }
        public CEmailService EmailService { get; set; }
        public CGenerate Generate { get; set; }
        public CInteraction Interaction { get; set; }
        public CQuery Query { get; set; }
        public CUri Uri { get; set; }
        public CCompression Compression { get; set; }
        public CObfuscation Obfuscation { get; set; }
        public CSqlBackup SqlBackup { get; set; } 
        #endregion

        #region Constructor(s)
        public CServices()
        {
            // initialize objects
            InitializeObjects();
        }
        #endregion

        #region Public Methods
        #endregion

        #region Private Methods
        private void InitializeObjects()
        {
            Language = new CLanguage();
            EmailService = new CEmailService();
            Generate = new CGenerate();
            Interaction = new CInteraction();
            Query = new CQuery();
            Uri = new CUri();
            Compression = new CCompression();
            Obfuscation = new CObfuscation();
            SqlBackup = new CSqlBackup();
        }
        #endregion
    }
}