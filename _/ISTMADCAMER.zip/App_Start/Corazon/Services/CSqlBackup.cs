﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace CorazonHeart
{
    public class CSqlBackup
    {
        #region Public Methods
        public bool CreateBackup(string databaseName, string outputPath)
        {
            // init feedback
            bool isSuccess = false;

            // get connection string
            string connectionString = @"Integrated Security=SSPI;Persist Security Info=False;User ID=KEN\Ken Danani;Initial Catalog=Summer;Data Source=KEN\DSERVER";

            try
            {
                 // init con
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // init query
                    string query = String.Format("BACKUP DATABASE [{0}] TO  DISK = '{1}'", databaseName, outputPath);
                    SqlCommand cmd = new SqlCommand(query, con);

                    // execute query
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                isSuccess = false;
            }

            return isSuccess;
        }
        #endregion
    }
}