﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace CorazonHeart
{
    /// <summary>
    /// Provides functionalities to build and run generic queries.
    /// </summary>
    public class CQuery
    {
        #region Data Members and Enums
        public enum QueryType
        {
            Insert = 1,
            Update = 2,
            Delete = 3,
            Select = 4
        }
        #endregion

        #region Public Methods
        public int? Execute(QueryType type, string tableName, List<string> columnNames, List<object> values, string condition = null, bool noDBNull = true)
        {
            // if type is not valid, return null and don't proceed
            if (type == QueryType.Select)
                return null;

            // get the app object
            Corazon app = Corazon.Current;

            // init result to null
            int? result = null;

            // validation
            int? count = ValidateAndGetCount(columnNames, values);
            if (count == null) return null;

            // get the query
            string query = BuildQuery(type, tableName, columnNames, values, condition, noDBNull);
            try
            {
                // init con
                using (SqlConnection con = new SqlConnection(app.ConnectionString))
                {
                    con.Open();

                    // init command
                    SqlCommand cmd = new SqlCommand(query, con);

                    // init parameters
                    for (int i = 0; i < count; i++)
                    {
                        AddParameter(ref cmd, columnNames[i], values[i]);
                    }

                    // execute query
                    if (type == QueryType.Insert)
                    {
                        // execute the insert query, and get the primary key (ID) returned
                        result = Convert.ToInt32(cmd.ExecuteScalar());
                    }
                    else
                    {
                        // execute update/delete query, and assign result to true if affected row > 0
                        if (cmd.ExecuteNonQuery() > 0)
                            result = 1;     // assign non-null value to result (successful)
                    }
                }
            }
            catch (Exception)
            {
                // error occured
                result = null;
            }

            return result;
        }
        public DataTable ExecuteSelect(string query)
        {
            // get the app object
            Corazon app = Corazon.Current;

            DataTable result = new DataTable();

            try
            {
                // init con
                using (SqlConnection con = new SqlConnection(app.ConnectionString))
                {
                    con.Open();

                    // execute query and fill to result dt
                    SqlDataAdapter da = new SqlDataAdapter(query, con);
                    da.Fill(result);
                }
            }
            catch (Exception)
            {
                result = null;
            }

            return result;
        }
        public DataTable ExecuteSelect(string tableName, List<string> columnNames, string condition = null, string orderBy = null)
        {
            // build the query
            string query = BuildSelectQuery(tableName, columnNames, condition, orderBy);

            return ExecuteSelect(query);
        }
        public DataTable ExecuteSelect(List<string> tableNames, List<string> columnNames, List<string[]> joinColumns, string condition = null, string orderBy = null)
        {
            // build the query
            string query = BuildSelectQuery(tableNames, columnNames, joinColumns, condition, orderBy);

            return ExecuteSelect(query);
        }
        public bool ExecuteDelete(string tableName, string condition = null)
        {
            int? feedback = Execute(QueryType.Delete, tableName, null, null, condition);

            // return true if feedback is not null (successful), false otherwise
            return feedback != null;
        }

        public string BuildQuery(QueryType type, string tableName, List<string> columnNames, List<object> values, string condition = null, bool noDBNull = true)
        {
            // check if type = Select, don't proceed
            if (type == QueryType.Select)
                return BuildSelectQuery(tableName, columnNames, condition);

            // get the app object
            Corazon app = Corazon.Current;

            // variables
            StringBuilder sb = new StringBuilder();
            string result = "";

            // validation
            int? count = ValidateAndGetCount(columnNames, values);
            if (count == null) return null;

            try
            {
                switch (type)
                {
                    case QueryType.Insert:
                        sb.AppendFormat("INSERT INTO {0} ", tableName);
                        sb.Append("(");

                        // loop through all the column names
                        foreach (string columnName in columnNames)
                        {
                            sb.AppendFormat("{0},", columnName);
                        }
                        // remove one comma, close the bracket, and append ' VALUES ('
                        sb.Remove(sb.Length - 1, 1);
                        sb.Append(") VALUES(");

                        // loop through all the column names and add parameter names
                        foreach (string columnName in columnNames)
                        {
                            sb.AppendFormat("@{0},", columnName);
                        }
                        // remove one comma, and add SELECT SCOPE_IDENTITY SQL Function
                        sb.Remove(sb.Length - 1, 1);
                        sb.Append("); SELECT SCOPE_IDENTITY();");
                        break;
                    case QueryType.Update:
                        sb.AppendFormat("UPDATE {0} ", tableName);
                        sb.Append("SET ");

                        // loop through all the column names, and add the parameter name also
                        for (int i = 0; i < count; i++)
                        {
                            // append the query if noDBNull = false OR noDBNull = true and value is not null
                            if (!noDBNull || values[i] != null)
                                sb.AppendFormat("{0}=@{1},", columnNames[i], columnNames[i]);
                        }
                        // remove one comma
                        sb.Remove(sb.Length - 1, 1);
                        break;
                    case QueryType.Delete:
                        sb.AppendFormat("DELETE FROM {0}", tableName);
                        break;
                }
                result = sb.ToString();

                // check if condition is not null, append it to the query we are going to return
                if (condition != null && condition != "")
                    result += " WHERE " + condition;
            }
            catch (Exception)
            {
                result = null;
            }

            return result;
        }
        public string BuildSelectQuery(string tableName, List<string> columnNames, string condition = null, string orderBy = null)
        {
            // get the app object
            Corazon app = Corazon.Current;

            // variables
            StringBuilder sb = new StringBuilder();
            string result = "";

            try
            {
                sb.Append("SELECT ");

                // columns
                if (columnNames == null || columnNames.Count == 0)
                    sb.Append("* ");
                else
                {
                    foreach (string columnName in columnNames)
                    {
                        sb.AppendFormat("{0},", columnName);
                    }

                    // remove the last comma
                    sb.Remove(sb.Length - 1, 1);
                }

                sb.AppendFormat(" FROM {0}", tableName);

                result = sb.ToString();

                // check if condition is not null, append it to the query we are going to return
                if (condition != null && condition != "")
                    result += " WHERE " + condition;
                if (orderBy != null)
                    result += " ORDER BY " + orderBy;
            }
            catch (Exception)
            {
                result = null;
            }

            return result;
        }
        public string BuildSelectQuery(List<string> tableNames, List<string> columnNames, List<string[]> joinColumns, string condition = null, string orderBy = null)
        {
            // get the app object
            Corazon app = Corazon.Current;

            // variables
            StringBuilder sb = new StringBuilder();
            string result = "";

            try
            {
                sb.Append("SELECT ");

                // columns
                if (columnNames == null || columnNames.Count == 0)
                    sb.Append("* ");
                else
                {
                    foreach (string columnName in columnNames)
                    {
                        sb.AppendFormat("{0},", columnName);
                    }

                    // remove the last comma
                    sb.Remove(sb.Length - 1, 1);
                }

                for (int i = 0; i < tableNames.Count; i++)
                {
                    if (i == 0)
                        sb.AppendFormat(" FROM {0}", tableNames[i]);
                    else
                    {
                        sb.AppendFormat(" INNER JOIN {0} ON {1}={2}", tableNames[1], joinColumns[i][0], joinColumns[i][1]);
                    }
                }

                result = sb.ToString();

                // check if condition is not null, append it to the query we are going to return
                if (condition != null && condition != "")
                    result += " WHERE " + condition;
                if (orderBy != null)
                    result += " ORDER BY " + orderBy;
            }
            catch (Exception)
            {
                result = null;
            }

            return result;
        }

        public void AddParameter(ref SqlCommand cmd, string parameterName, SqlDbType dbType, object value, bool noDBNull = true)
        {
            if (value != null)
            {
                cmd.Parameters.Add(parameterName, dbType).Value = value;
            }
            else if (noDBNull)
            {
                // if value is null, and noDBNull is true
                cmd.Parameters.Add(parameterName, dbType).Value = DBNull.Value;
            }
        }
        public void AddParameter(ref SqlCommand cmd, string parameterName, object value, bool noDBNull = true)
        {
            SqlParameter parameter = new SqlParameter();
            if (value == null)
            {
                parameter = new SqlParameter(parameterName, DBNull.Value);
            }
            else
            {
                parameter = new SqlParameter(parameterName, value);
                cmd.Parameters.Add(parameter);
            }

            if (value == null && noDBNull)
                cmd.Parameters.Add(parameter);
        }
        #endregion

        #region Private Methods
        private int? ValidateAndGetCount(List<string> columnNames, List<object> values)
        {
            // if either list is null, return 0 as count
            if (columnNames == null || values == null)
                return 0;

            // validation, all list passed must have the same count
            if (!(columnNames.Count == values.Count))
                return null;
            else return columnNames.Count;      // return any one (both are the same)
        }
        #endregion
    }
}