﻿using CorazonHeart;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

/// <summary>
/// Provides interaction functionalities with Media table.
/// </summary>
public class CMedia
{
    /// <summary>
    /// Add a new media.
    /// </summary>
    /// <param name="mediaType">The media type.</param>
    /// <param name="fileName">The file name without extension.</param>
    /// <param name="fileExtension">The file extension.</param>
    /// <returns>Returns the ID of the media if successful, null otherwise.</returns>
    public int? Add(MediaType mediaType, string fileName, string fileExtension)
    {
        // [validation] media type cannot be all to insert into the database
        if (mediaType == MediaType.All)
            return null;

        // init return value
        int? id = null;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // execute insert query to db
            id = corazon.Services.Query.Execute(CQuery.QueryType.Insert,
                    "Media",
                    new List<string>() { "TypeID", "FileName", "FileExtension" },
                    new List<object>() { (int)mediaType, fileName, fileExtension }
                    );
        }
        catch (Exception)
        {
            id = null;
        }

        return id;
    }

    /// <summary>
    /// Assign a media to a user.
    /// </summary>
    /// <param name="mediaID">The ID of the media.</param>
    /// <param name="userID">The user ID which owns this media.</param>
    /// <returns>Returns true if successful, false otherwise.</returns>
    public bool AssignUserMedia(int mediaID, int userID)
    {
        // init return value
        bool isSuccess = false;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // init id
            int? id = null;

            // get all the current medias assigned to the user
            DataTable dt = corazon.Services.Query.ExecuteSelect("UserMedia",
                null,
                "UserID=" + userID
                );

            if (dt == null || dt.Rows.Count == 0)
            {
                // user media doesn't exist yet, execute insert query to db
                id = corazon.Services.Query.Execute(CQuery.QueryType.Insert,
                    "UserMedia",
                    new List<string>() { "MediaID", "UserID" },
                    new List<object>() { mediaID, userID }
                    );
            }
            else
            {
                // user media exist, execute update query to db
                string condition = "UserID=" + userID;
                id = corazon.Services.Query.Execute(CQuery.QueryType.Update,
                    "UserMedia",
                    new List<string>() { "MediaID" },
                    new List<object>() { mediaID },
                    condition, true
                    );
            }

            // assign is-success flag
            isSuccess = id == null ? false : true;
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }
    
    /// <summary>
    /// Assign a media to a place.
    /// </summary>
    /// <param name="mediaID">The ID of the place.</param>
    /// <param name="placeID">The place ID which owns this media.</param>
    /// <returns>Returns true if successful, false otherwise.</returns>
    public bool AssignPlaceMedia(int mediaID, int placeID)
    {
        // init return value
        bool isSuccess = false;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // init id
            int? id = null;

            // get all the current medias assigned to the place
            DataTable dt = corazon.Services.Query.ExecuteSelect("PlaceMedia",
                null,
                "PlaceID=" + placeID
                );

            if (dt == null || dt.Rows.Count == 0)
            {
                // user media doesn't exist yet, execute insert query to db
                id = corazon.Services.Query.Execute(CQuery.QueryType.Insert,
                    "PlaceMedia",
                    new List<string>() { "MediaID", "PlaceID" },
                    new List<object>() { mediaID, placeID }
                    );
            }
            else
            {
                // user media exist, execute update query to db
                string condition = "PlaceID=" + placeID;
                id = corazon.Services.Query.Execute(CQuery.QueryType.Update,
                    "PlaceMedia",
                    new List<string>() { "MediaID" },
                    new List<object>() { mediaID },
                    condition, true
                    );
            }

            // assign is-success flag
            isSuccess = id == null ? false : true;
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }


    /// <summary>
    /// Assign a media to an exhibition.
    /// </summary>
    /// <param name="exhibitionID">The ID of the exhibition.</param>
    /// <param name="placeID">The exhibition ID which owns this media.</param>
    /// <returns>Returns true if successful, false otherwise.</returns>
    public bool AssignExhibitionMedia(int mediaID, int exhibitionID)
    {
        // init return value
        bool isSuccess = false;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // init id
            int? id = null;

            // get all the current medias assigned to the user
            DataTable dt = corazon.Services.Query.ExecuteSelect("ExhibitionMedia",
                null,
                "ExhibitionID=" + exhibitionID
                );

            if (dt == null || dt.Rows.Count == 0)
            {
                // user media doesn't exist yet, execute insert query to db
                id = corazon.Services.Query.Execute(CQuery.QueryType.Insert,
                    "ExhibitionMedia",
                    new List<string>() { "MediaID", "ExhibitionID" },
                    new List<object>() { mediaID, exhibitionID }
                    );
            }
            else
            {
                // user media exist, execute update query to db
                string condition = "ExhibitionID=" + exhibitionID;
                id = corazon.Services.Query.Execute(CQuery.QueryType.Update,
                    "ExhibitionMedia",
                    new List<string>() { "MediaID" },
                    new List<object>() { mediaID },
                    condition, true
                    );
            }

            // assign is-success flag
            isSuccess = id == null ? false : true;
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }
}