﻿using CorazonHeart;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

/// <summary>
/// Provides interaction functionalities with CUser table.
/// </summary>
public class CUser
{
    #region Data Members
    public int ID { get; set; }
    public string Name { get; set; }
    #endregion

    #region CRUD
    /// <summary>
    /// Get all users.
    /// </summary
    /// <param name="userType">(Optional) The user type. Pass this parameter is the intention is to get all users of a particular type.</param>>
    /// <param name="sortColumnName">(Optional) The column name to sort.</param>
    /// <param name="sortOrder">(Optional) Sort order to retrieve the data.</param>
    /// <returns>Returns all matching room facilities if successful, null otherwise.</returns>
    public DataTable GetAll(UserType userType = UserType.All, string sortColumnName = "", SortOrder sortOrder = SortOrder.Unspecified)
    {
        // get the app object
        Fefeo app = Fefeo.Current;

        // init extended query and order query rule
        string extendedQuery = "", orderQueryRule = "";

        // if user type is specified
        if (userType != UserType.All)
        {
            extendedQuery = " AND TypeID = " + (int)userType;
        }

        // if sort order is not unspecified, build the query for it
        if (sortOrder != SortOrder.Unspecified)
        {
            if (sortOrder == SortOrder.Ascending)
                orderQueryRule = String.Format(" ORDER BY {0}", sortColumnName);
            else
            {
                orderQueryRule = String.Format(" ORDER BY {0} DESC", sortColumnName);
            }
        }

        // init result
        DataTable result = new DataTable();

        try
        {
            // init con
            using (SqlConnection con = new SqlConnection(app.ConnectionString))
            {
                con.Open();

                // init query
                string query = "SELECT * FROM CUserView WHERE 1=1"
                    + extendedQuery
                    + orderQueryRule;
                SqlCommand cmd = new SqlCommand(query, con);

                // execute the query and store the result in the DataTable
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(result);
            }
        }
        catch (Exception)
        {
            // error occured
            result = null;
        }

        return result;
    }

    /// <summary>
    /// Get a specified user.
    /// </summary>
    /// <param name="id">The ID of the user to get.</param>
    /// <returns>Returns the data of the user if exists, null/empty DataTable otherwise.</returns>
    public DataTable Get(int id)
    {
        // get the app object
        Fefeo app = Fefeo.Current;

        // init result
        DataTable result = new DataTable();

        try
        {
            // init con
            using (SqlConnection con = new SqlConnection(app.ConnectionString))
            {
                con.Open();

                // init query
                string query = "SELECT * FROM CUserView WHERE ID=@ID";
                SqlCommand cmd = new SqlCommand(query, con);

                // parameters
                cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id;

                // execute the query and store the result in the DataTable
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(result);
            }
        }
        catch (Exception)
        {
            // error occured
            result = null;
        }

        return result;
    }

    /// <summary>
    /// Add a new user.
    /// </summary>
    /// <param name="userType">The user type of the user.</param>
    /// <param name="name">The name of the user.</param>
    /// <param name="email">(Optional) The email address of the user used to login.</param>
    /// <param name="password">(Optional) The raw (not-hashed) password of the user used to login.</param>
    /// <param name="description">(Optional) The description of the user in English.</param>
    /// <param name="descriptionFr">(Optional) The description of the user in French.</param>
    /// <param name="startDate">(Optional) The start date of the user (in case of user type = king).</param>
    /// <param name="endDate">(Optional) The end date of the user (in case of user type = king).</param>
    /// <returns>Returns the ID of the user if successful, null otherwise.</returns>
    public int? Add(UserType userType, string name, string email = null, string password = null, string description = null, string descriptionFr = null, DateTime? startDate = null, DateTime? endDate = null)
    {
        // [validation] user type cannot be all to insert into the database
        if (userType == UserType.All)
            return null;

        // init return value
        int? id = null;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            //// if password is not null, hash them
            //if (password != null && !String.IsNullOrWhiteSpace(password))
            //    password = corazon.Security.Crypto.CreateHash(password);

            // execute insert query to db
            id = corazon.Services.Query.Execute(CQuery.QueryType.Insert,
                    "CUser",
                    new List<string>() { "TypeID", "Name", "Email", "Password", "Description", "DescriptionFrench", "StartDate", "EndDate" },
                    new List<object>() { (int)userType, name, email, password, description, descriptionFr, startDate, endDate }
                    );
        }
        catch (Exception)
        {
            id = null;
        }

        return id;
    }

    /// <summary>
    /// Update user details.
    /// </summary>
    /// <param name="id">The ID of the user to update.</param>
    /// <param name="name">The name of the user.</param>
    /// <param name="email">(Optional) The email address of the user used to login.</param>
    /// <param name="password">(Optional) The raw (not-hashed) password of the user used to login.</param>
    /// <param name="description">(Optional) The description of the user in English.</param>
    /// <param name="descriptionFr">(Optional) The description of the user in French.</param>
    /// <param name="startDate">(Optional) The start date of the user (in case of user type = king).</param>
    /// <param name="endDate">(Optional) The end date of the user (in case of user type = king).</param>
    /// <returns>Returns true if successful, false otherwise.</returns>
    public bool Update(int id, string name, string email = null, string password = null, string description = null, string descriptionFr = null, DateTime? startDate = null, DateTime? endDate = null)
    {
        // init return value
        bool isSuccess = false;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // if password is not null, hash them
            if (password != null && !String.IsNullOrWhiteSpace(password))
                password = corazon.Security.Crypto.CreateHash(password);

            // execute insert query to db
            string condition = "ID=" + id;
            isSuccess = corazon.Services.Query.Execute(CQuery.QueryType.Update,
                    "CUser",
                    new List<string>() { "Name", "Email", "Password", "Description", "DescriptionFrench", "StartDate", "EndDate" },
                    new List<object>() { name, email, password, description, descriptionFr, startDate, endDate },
                    condition, true
                    ) != null;
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }

    /// <summary>
    /// Delete a user.
    /// </summary>
    /// <param name="id">The ID of the user to delete.</param>
    /// <returns>Returns true if successful, false otherwise.</returns>
    public bool Delete(int id)
    {
        // init return value
        bool isSuccess = false;

        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // execute insert query to db
            string condition = "ID=" + id;
            isSuccess = corazon.Services.Query.Execute(CQuery.QueryType.Delete,
                    "CUser",
                    null,
                    null,
                    condition
                    ) != null;
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }
    #endregion

    #region Sign In/Out
    public bool SignIn(string username, string password)
    {
        // init result 
        bool isSuccess = false;

        try
        {
            // get the app object
            Fefeo app = Fefeo.Current;

            // init con
            using(SqlConnection con = new SqlConnection(app.ConnectionString))
            {
                con.Open();

                // init query
                string query = "SELECT ID, Name, Email, Password FROM CUserView WHERE Email=@Email;";
                SqlCommand cmd = new SqlCommand(query, con);

                // assign parameters
                cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = username;

                // execute query
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(dt);

                if(dt != null && dt.Rows.Count > 0)
                {
                    // get the hashed password from db
                    string hashedPassword = dt.Rows[0]["Password"].ToString();

                    // get the corazon object
                    Corazon corazon = Corazon.Current;

                    // compare the password with security standards - slow equals
                    isSuccess = corazon.Security.Crypto.ValidatePassword(password, hashedPassword);

                    // if password validation is successful:
                    if(isSuccess)
                    {
                        // parse the ID safely
                        int id = -1;
                        if (!Int32.TryParse(dt.Rows[0]["ID"].ToString(), out id))
                            throw new Exception();

                        // store the current user logged in in session object
                        Fefeo.CPCurrent = app;
                        Fefeo.CPCurrent.IsLoggedIn = true;

                        // assign the details for the current user
                        this.ID = id;
                        this.Name = dt.Rows[0]["Name"].ToString();
                        app.User = this;

                        // redirect to cp page
                        HttpContext.Current.Response.Redirect("~/cp");
                    }
                }
            }
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }

    public bool SignOut()
    {
        // init result 
        bool isSuccess = false;

        try
        {
            Fefeo.CPCurrent.IsLoggedIn = false;
            Fefeo.CPCurrent = null;
            isSuccess = true;

            HttpContext.Current.Response.Redirect("~/cp/login");
        }
        catch (Exception)
        {
            isSuccess = false;
        }

        return isSuccess;
    }
    #endregion
}