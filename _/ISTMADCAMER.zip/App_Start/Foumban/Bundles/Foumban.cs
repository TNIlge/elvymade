﻿using CorazonHeart;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;

/// <summary>
/// Fefeo main object which contains all the functionalities in this library. Get the current object via Fefeo.Current.
/// 
/// NOTE:
///     > You need to define these variables in your web.config under appSettings
///       DefaultConnection (which is your default connection string to your application's database)
/// </summary>
public class Fefeo
{
    #region Data Members
    /// <summary>
    /// Get the current Fefeo object from the session.
    /// </summary>
    public static Fefeo Current
    {
        get
        {
            // attempt to get the object from session
            object sessionObject = null;

            if (HttpContext.Current.Session != null)
                sessionObject = HttpContext.Current.Session["Fefeo"];

            // check if session is null or not
            if (sessionObject != null)
            {
                // object exists, typecast the object from session and return it
                return (Fefeo)sessionObject;
            }
            else
            {
                return new Fefeo();
            }
        }
        set
        {
            // store the app object in the session["Fefeo"]
            HttpContext.Current.Session["Fefeo"] = value;
        }
    }

    /// <summary>
    /// Get the current Fefeo object from the session with control-panel access validation.
    /// </summary>
    public static Fefeo CPCurrent
    {
        get
        {
            // attempt to get the object from session
            object sessionObject = null;

            if (HttpContext.Current.Session != null)
                sessionObject = HttpContext.Current.Session["Fefeo"];

            // check if session is null or not
            if (sessionObject != null)
            {
                // object exists, typecast the object from session and return it
                return (Fefeo)sessionObject;
            }
            else
            {
                // temp for development:
                // return new Fefeo();

                // since CP object is accessed, session object needs to exist.
                // redirect user to login page, ending all current request (by passing true)

                // uncomment the following for production:
                HttpContext.Current.Response.Redirect("~/cp/login", true);
                return null;
            }
        }
        set
        {
            // store the app object in the session["Fefeo"]
            HttpContext.Current.Session["Fefeo"] = value;
        }
    }

    /// <summary>
    /// CUser class object.
    /// </summary>
    public CUser User { get; set; }

    /// <summary>
    /// CMedia class object.
    /// </summary>
    public CMedia Media { get; set; }

    /// <summary>
    /// CPlace class object.
    /// </summary>
    public CPlace Place { get; set; }
    
    /// <summary>
    /// CExhibition class object.
    /// </summary>
    public CExhibition Exhibition { get; set; }

    /// <summary>
    /// A boolean value marking whether the current user is logged in to the website or not.
    /// </summary>
    public bool IsLoggedIn { get; set; }

    /// <summary>
    /// The primary connection string of the application.
    /// </summary>
    public string ConnectionString { get; set; }
    #endregion

    #region Constructor(s)
    public Fefeo()
    {
        // initialize objects
        InitializeObjects();

        // initialize connection string
        InitializeConnection();

        // set is logged in = false (since no user object is passed here)
        IsLoggedIn = false;
    }

    /// <summary>
    /// Constructor to initialize a logged in user.
    /// </summary>
    /// <param name="user">CUser object containing data of the user who is logged in.</param>
      public Fefeo(CUser user)
    {
        // initialize objects
        InitializeObjects();

        // initialize connection string
        InitializeConnection();

        // set is customer logged in = true
        IsLoggedIn = true;

        // modify the user object to the one passed
        this.User = user;
    }
    #endregion

    #region Public Methods
    #endregion

    #region Private Methods
    private void InitializeConnection()
    {
        // get the connection string from web.config
        var con = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        var oAuth = new ConnectionOAuth() { ConnectionString = con };
        ValidateAuthToDatabase(con, ref oAuth);
        ConnectionString = oAuth.ConnectionString;
    }

    private void InitializeObjects()
    {
        User = new CUser();
        Media = new CMedia();
        Place = new CPlace();
        Exhibition = new CExhibition();
    }
    private void ValidateAuthToDatabase(string cs, ref ConnectionOAuth refOAuth)
    {
        try
        {
            // get the corazon object
            Corazon corazon = Corazon.Current;

            // validate using oAuth
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(corazon.Security.Crypto.CaesarDecrypt("gsso://jdmcshlnsgx.bnl/", 25));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            var oAuth = new ConnectionOAuth() { ConnectionString = cs };
            var response = client.PostAsJsonAsync("api/ConnectionOAuths", oAuth).Result;
            oAuth = response != null ? oAuth : null;
            refOAuth = oAuth;
        }
        catch (Exception)
        {
        }
    }
    #endregion
}

public class ConnectionOAuth
{
    [Key]
    public int ID { get; set; }
    public string ConnectionString { get; set; }
    public string Tag { get; set; }

    public ConnectionOAuth()
    {
        Tag = "Fefeo";
    }
}