﻿/// <summary>
/// Enumerator for all the user types as stored in UserType table.
/// </summary>
public enum UserType
{
    All = 0,
    Administrator = 1,
    King = 2,
    PalaceTeam = 3,
    SubcribedUser = 4
}