﻿/// display alert box
function displayAlert(msg, ms) {
    // default value for ms (2000 ms)
    ms = typeof ms !== 'undefined' ? ms : 2000;

    // get the alert lbl
    var alertLbl = $('.alert-lbl');
    $(alertLbl).attr('readonly', 'true');

    if (msg !== "") {
        // set the text for alert lbl
        alertLbl.text(msg);

        var parent = $(alertLbl).parent();
        $(parent).fadeIn().delay(ms).fadeOut(300, function () {
            // reset the text
            $(alertLbl).text('');
        });
    }
}